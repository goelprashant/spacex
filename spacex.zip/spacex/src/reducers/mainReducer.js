import {FETCH_PROGRAMS} from "../actions/types";

const initialState = {
  programs: []
}

export default (state = initialState, action) => {
  switch(action.type){
    case FETCH_PROGRAMS:
      return {
        ...state,
        programs: action.payload
      }
    default:
      return state;
  }
}