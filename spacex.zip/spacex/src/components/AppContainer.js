import React, {useEffect} from "react";
import {useDispatch, useSelector} from "react-redux";
import { useHistory, useLocation } from "react-router-dom";

import FilterCard from "./FilterCard";
import ProgramCard from "./ProgramCard";

import {fetchPrograms} from "../actions/fetchActions";

const AppContainer = () => {

  const dispatch = useDispatch();
  const history = useHistory();
  const location = useLocation();

  const {
    mainReducer: {programs}
  } = useSelector(state => state)


  useEffect(() => {
    async function getData(){
      dispatch(fetchPrograms());
    }

    getData()
  }, [])

  const getQuery = (year, launch_success, land_success) => {
    let query = "";

    if(year){
      query += `&launch_year=${year}`
    }

    if(launch_success !== null){
      query += `&launch_success=${launch_success}`;
    }

    if(land_success !== null){
      query += `&land_success=${land_success}`;
    }

    return query;
  }

  const filterByYear = (year) => {
    let searchParams = new URLSearchParams(location.search);
    searchParams.set("year", year)

    const launch_success = searchParams.get('launch_success');
    const land_success = searchParams.get('land_success');

    history.push({
      pathname: "/",
      search: searchParams.toString()
    })
    dispatch(fetchPrograms(getQuery(year, launch_success, land_success)));
  }

  const filterByLaunch = (launch_success) => {
    let searchParams = new URLSearchParams(location.search);
    searchParams.set("launch_success", launch_success)

    const year = searchParams.get('year');
    const land_success = searchParams.get('land_success');

    history.push({
      pathname: "/",
      search: searchParams.toString()
    })
    dispatch(fetchPrograms(getQuery(year, launch_success, land_success)));
  }

  const filterByLand = (land_success) => {
    let searchParams = new URLSearchParams(location.search);
    searchParams.set("land_success", land_success)

    const launch_success = searchParams.get('launch_success');
    const year = searchParams.get('year');

    history.push({
      pathname: "/",
      search: searchParams.toString()
    })
    dispatch(fetchPrograms(getQuery(year, launch_success, land_success)));
  }

  return (
    <div className="app-container">
      <div className="filter-card-container">
        <FilterCard filterByYear={filterByYear} filterByLaunch={filterByLaunch} filterByLand={filterByLand} />
      </div>
      <div className="programs-container">
        {programs.length ? programs.map(program => {
          return <ProgramCard key={program.flight_namber} program={program} />
        }) : <div>Loading</div>
          
        }
      </div>
    </div>
  )
}

export default AppContainer;