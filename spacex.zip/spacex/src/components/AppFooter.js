import React from "react";

const AppFooter = () => {
  return (
    <footer>Developed by: Prashant Goel</footer>
  )
}

export default AppFooter;