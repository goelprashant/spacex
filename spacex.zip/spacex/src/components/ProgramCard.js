import React from "react";

const ProgramCard = (props) => {

  const {launch_year, links: {mission_patch_small}, launch_success, mission_id, rocket: {rocket_name}, launch_landing} = props.program;
  
  return (
    <div className="program-card-wrapper">
      <div className="program-card-image-holder">
        <img className="program-card-image" alt="rocket" src={mission_patch_small} />
      </div>
      <div className="program-card-name">{rocket_name}</div>
      <div>
        <div className="program-card-key">Mission Ids:</div>
        <ul className="program-mission-ids program-card-value">
          {mission_id.map(id => {
            return <li key={id}>{id}</li>
          })}
        </ul>
      </div>
      <div className="display-flex">
        <div className="program-card-key">Launch year: </div>
        <div className="program-card-value">{launch_year}</div>
      </div>
      <div className="display-flex">
        <div className="program-card-key">Successful Launch: </div>
        <div className="program-card-value">{String(launch_success)}</div>
      </div>
      <div className="display-flex">
        <div className="program-card-key">Successful Landing: </div>
        <div className="program-card-value">{launch_landing != undefined && String(launch_landing)}</div>
      </div>
    </div>
  )
}

export default ProgramCard;