import React from "react";

const AppHeader = () => {
  return (
    <header>Spacex Launch Programs</header>
  )
}

export default AppHeader;