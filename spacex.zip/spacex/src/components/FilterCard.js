import React, {useState} from "react";

const FilterCard = (props) => {
  const years = [2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020];

  const [activeYear, setActiveYear] = useState();
  const [launch, setLaunch] = useState();
  const [land, setland] = useState();

  const filterByYear = (val) => {
    setActiveYear(val);
    props.filterByYear(val);
  }
  const filterByLaunch = (val) => {
    setLaunch(val);
    props.filterByLaunch(val);
  }

  const filterByLand = (val) => {
    setland(val);
    props.filterByLand(val)
  }

  return (
    <div>
      <div className="filter-card-heading">Filters</div>
      <div className="filter-heading">Launch Year</div>
      <div className="button-container">
        {years.map(year => <button className={activeYear === year ? 'active' : ''} key={year} onClick={() => filterByYear(year)}>{year}</button>)}
      </div>
      <div className="filter-heading">Successful Launch</div>
      <div className="button-container">
        <button className={launch === true ? 'active' : ''} onClick={() => filterByLaunch(true)}>True</button>
        <button className={launch === false ? 'active' : ''} onClick={() => filterByLaunch(false)}>False</button>
      </div>
      <div className="filter-heading">Successful land</div>
      <div className="button-container">
        <button className={land === true ? 'active' : ''} onClick={() => filterByLand(true)}>True</button>
        <button className={land === false ? 'active' : ''} onClick={() => filterByLand(false)}>False</button>
      </div>
    </div>
  )
}

export default FilterCard;