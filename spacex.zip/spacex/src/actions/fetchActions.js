import { queryAllByAltText } from "@testing-library/react";
import axios from "axios";

import {
  PROGRAM_API
} from "../config/remoteUrls";
import { FETCH_PROGRAMS } from "./types";

export const fetchPrograms = query => dispatch => {
  let api = PROGRAM_API;
  if(query){
    api = PROGRAM_API + query;
  }

  axios
    .get(api)
    .then(res => {
      dispatch({
        type: FETCH_PROGRAMS,
        payload: res.data
      });
    })
    .catch(err => console.log(err.message));
};