import React from "react";
import './App.css';
import { Provider } from "react-redux";
import { BrowserRouter as Router, Route } from "react-router-dom";
import store from "./store";

import AppHeader from "./components/AppHeader";
import AppContainer from "./components/AppContainer";
import AppFooter from "./components/AppFooter";

function App() {
  return (
    <Provider store={store}>
      <Router>
        <div className="App">
          <AppHeader />
          <Route exact path="/" component={AppContainer} />
          <AppFooter />
        </div>
      </Router>
    </Provider>
  );
}

export default App;
